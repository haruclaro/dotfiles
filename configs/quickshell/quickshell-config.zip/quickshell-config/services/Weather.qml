pragma Singleton
import QtQuick
import Quickshell
import Quickshell.Io
import "../config" as Cfg

// PORTADO de Bar.tsx: mesma lógica (fetch normal via weather.sh, refresh de
// localização via "weather.sh toggle" + novo fetch, e set manual de cidade
// via weather-set-city.sh + novo fetch). O script deve continuar imprimindo
// {"text":...,"tooltip":...} em JSON.
//
// CORRIGIDO (log: "Weather: falha ao interpretar JSON: SyntaxError"): antes
// chamávamos "bash -c <caminho>", que faz o bash tentar EXECUTAR o arquivo
// diretamente — e isso exige permissão +x, que se perde facilmente ao
// copiar/zipar a config. Trocamos pra "bash <caminho>", onde é o próprio
// bash que lê e interpreta o conteúdo do script, sem precisar de +x.
QtObject {
    id: root

    property string text: "…"
    property string icon: ""
    property string temp: "…"
    property string tooltip: "A carregar"
    property bool loading: true

    function _applyResult(out) {
        try {
            const parsed = JSON.parse(out)
            root.text = typeof parsed.text === "string" ? parsed.text : "⚠ Erro"
            // "icon"/"temp" são novos (ver scripts/weather.sh); se o script
            // ainda for uma versão antiga sem esses campos, caímos de volta
            // pro "text" combinado inteiro no lugar da temperatura, sem
            // ícone — funciona, só sem a separação de fonte.
            root.icon = typeof parsed.icon === "string" ? parsed.icon : ""
            root.temp = typeof parsed.temp === "string" ? parsed.temp : root.text
            root.tooltip = typeof parsed.tooltip === "string" ? parsed.tooltip : ""
        } catch (e) {
            console.warn("Weather: falha ao interpretar JSON:", e)
            root.text = "⚠ Erro"
            root.icon = ""
            root.temp = "Erro"
            root.tooltip = "Falha ao ler o weather.sh"
        }
        root.loading = false
    }

    function refresh() {
        root.loading = true
        fetchProc.running = true
    }

    // Clique esquerdo: força atualização de localização + tempo
    function refreshLocationThenFetch() {
        root.loading = true
        toggleProc.running = true
    }

    // Clique direito: abre prompt de cidade manual, depois relê o tempo
    function promptCity() {
        root.loading = true
        setCityProc.running = true
    }

    property Process fetchProc: Process {
        command: ["bash", Cfg.Config.weatherScript]
        stdout: StdioCollector {
            onStreamFinished: root._applyResult(this.text)
        }
        onExited: (code) => {
            if (code !== 0) {
                root.text = "⚠ Erro"
                root.tooltip = "Falha ao ler o weather.sh"
                root.loading = false
            }
        }
    }

    property Process toggleProc: Process {
        command: ["bash", Cfg.Config.weatherScript, "toggle"]
        onExited: root.refresh()
    }

    property Process setCityProc: Process {
        command: ["bash", Cfg.Config.weatherSetCityScript]
        onExited: root.refresh()
    }

    property Timer pollTimer: Timer {
        interval: Cfg.Config.weatherIntervalMs
        running: true
        repeat: true
        onTriggered: root.refresh()
    }

    Component.onCompleted: refresh()
}
