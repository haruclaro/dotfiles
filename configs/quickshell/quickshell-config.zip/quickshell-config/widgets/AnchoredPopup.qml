import QtQuick
import Quickshell
import "../config" as Cfg

// PEDIDO/PORTADO: no AGS (GTK3) não dava pra posicionar um popup relativo a
// um botão sem pedir ajuda ao Hyprland via hyprctl (ver Popover.tsx antigo).
// O Quickshell resolve isso nativamente com PopupWindow.anchor.item — não
// precisamos mais de nenhum script externo pra isso.
//
// CORRIGIDO (clicar fora não fechava): a tentativa anterior usava
// HyprlandFocusGrab, mas essa API existe pra um caso mais avançado
// ("detectar clique fora SEM fechar o popup", segundo a doc oficial). O
// que a gente quer — fechar automaticamente ao clicar fora — já é uma
// propriedade nativa e direta do próprio PopupWindow: `grabFocus`. Só
// faltava setar ela.
//
// Uso:
//   AnchoredPopup {
//       id: myPopup
//       anchorItem: someButton
//       contentComponent: Component { MyPanelContent {} }
//   }
//   myPopup.toggle()
PopupWindow {
    id: root

    property Item anchorItem
    property Component contentComponent
    // Edges.Bottom | Edges.Right por padrão (cresce pra baixo, alinhado à direita do botão)
    property int edges: Edges.Bottom | Edges.Right
    property int popupMargin: 8

    implicitWidth: loader.item ? loader.item.implicitWidth + Cfg.Config.contentPadding * 2 : 1
    implicitHeight: loader.item ? loader.item.implicitHeight + Cfg.Config.contentPadding * 2 : 1
    visible: false
    color: "transparent"

    // A propriedade que fecha o popup ao clicar fora dele.
    grabFocus: true

    anchor.item: anchorItem
    anchor.edges: edges
    anchor.gravity: edges
    anchor.margins.top: popupMargin
    anchor.margins.bottom: popupMargin

    function toggle() {
        if (root.visible) {
            root.visible = false
        } else {
            root.anchor.updateAnchor()
            root.visible = true
        }
    }

    function close() { root.visible = false }

    Rectangle {
        id: frame
        anchors.fill: parent
        radius: Cfg.Config.barRadius
        color: Cfg.Colors.bgElevated
        border.color: Cfg.Colors.border
        border.width: 1

        focus: root.visible
        Keys.onEscapePressed: root.close()

        Loader {
            id: loader
            anchors.fill: parent
            anchors.margins: Cfg.Config.contentPadding
            sourceComponent: root.contentComponent
            active: root.visible
        }
    }
}
