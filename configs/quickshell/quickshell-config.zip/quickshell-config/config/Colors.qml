pragma Singleton
import QtQuick
import Quickshell.Io

// INTEGRADO: trocar_tema.sh escreve ~/.config/quickshell/theme-colors.json
// (ver scripts/trocar_tema.sh). Este FileView observa o arquivo
// (watchChanges: true) e as cores abaixo são bindings DIRETOS em cima do
// JSON parseado — não passam por nenhuma função "aplicar manualmente"
// disparada por sinal.
//
// CORRIGIDO (tema retro não recarregava a TopBar): a versão anterior lia
// o arquivo dentro de um handler `onLoaded` + `onFileChanged: reload()`
// escritos à mão — não consegui confirmar com certeza que esses sinais
// existem/disparam do jeito que eu esperava nessa versão do Quickshell.
// A doc oficial usa um padrão mais simples e à prova de sinais errados:
// `blockLoading: true` (garante que text() já tem conteúdo pronto pra
// ler) + uma property comum fazendo `JSON.parse(fileView.text())` — como
// é um binding declarativo normal, ele reavalia sozinho toda vez que
// `text()` muda (inclusive quando watchChanges detecta o arquivo mudando
// depois de rodar trocar_tema.sh), sem precisar de nenhum sinal manual.
QtObject {
    id: root

    property FileView themeFile: FileView {
        // Caminho fixo: como o script escreve fora da pasta do repo
        // (~/.config/quickshell/theme-colors.json), usamos o mesmo
        // diretório do shell.qml (raiz da config).
        path: Qt.resolvedUrl("../theme-colors.json")
        watchChanges: true
        blockLoading: true
        // Log "File does not exist" é esperado até rodar trocar_tema.sh
        // pela primeira vez — silenciado de propósito, já tratado abaixo
        // (cai no fallback).
        printErrors: false
    }

    readonly property var themeJson: {
        try {
            const parsed = JSON.parse(root.themeFile.text())
            return (parsed && typeof parsed === "object") ? parsed : null
        } catch (e) {
            return null
        }
    }

    // "fundo/superficie/base/destaque1/destaque2/texto" são os nomes que
    // trocar_tema.sh já usava (ver @define-color no CSS antigo do AGS) —
    // mapeamos pros tokens abaixo em vez de inventar nomes novos no script.
    // Cada cor cai no valor padrão (paleta escura estilo Caelestia) se o
    // JSON ainda não existir ou não tiver aquela chave específica.
    readonly property color bg: themeJson?.fundo ? ("#" + themeJson.fundo) : "#11121a"
    readonly property color bgAlt: themeJson?.superficie ? ("#" + themeJson.superficie) : "#1a1c2b"
    readonly property color bgElevated: themeJson?.superficie ? ("#" + themeJson.superficie) : "#20222f"
    readonly property color text: themeJson?.texto ? ("#" + themeJson.texto) : "#cad3f5"
    readonly property color subtext: themeJson?.texto ? ("#" + themeJson.texto) : "#a5adcb"
    readonly property color dim: "#6e7383"
    readonly property color accent: themeJson?.destaque1 ? ("#" + themeJson.destaque1) : "#8aadf4"
    readonly property color accentDim: themeJson?.destaque1 ? ("#" + themeJson.destaque1) : "#5b7bc4"
    readonly property color good: "#a6da95"
    readonly property color warning: "#eed49f"
    readonly property color critical: themeJson?.destaque2 ? ("#" + themeJson.destaque2) : "#ed8796"
    readonly property color border: themeJson?.base ? ("#" + themeJson.base) : "#2c2f42"
    readonly property color divider: themeJson?.base ? ("#" + themeJson.base) : "#2a2c3d"
    readonly property color hoverOverlay: "#2a2d40"
    readonly property color pressOverlay: "#33374d"
    readonly property color shadow: "#00000080"
}
