import QtQuick
import QtQuick.Layouts
import Quickshell.Io
import "../config" as Cfg
import "../services" as Services

// PEDIDO: "módulo pra criar novos temas, levando em consideração esquema
// de cores e seleção de wallpaper". Sem um seletor de arquivo nativo
// disponível de forma confiável (módulos Qt.labs.* já se mostraram
// pouco confiáveis nesse ambiente — ver o histórico do calendário),
// listamos os arquivos de imagem encontrados em pastas comuns de
// wallpaper e deixamos escolher clicando, com um campo de caminho manual
// como alternativa. Ao salvar, chama scripts/apply-custom-theme.sh —
// mesma lógica do trocar_tema.sh original, só que parametrizada.
Item {
    id: root
    implicitWidth: 340
    implicitHeight: col.implicitHeight

    // Pré-preenche com as cores ATUAIS (as que o Colors.qml já está
    // usando), pra editar em cima de algo em vez de começar do zero.
    property string themeName: "Meu Tema"
    property string fundo: Cfg.Colors.bg.toString().replace("#", "")
    property string superficie: Cfg.Colors.bgAlt.toString().replace("#", "")
    property string base: Cfg.Colors.border.toString().replace("#", "")
    property string destaque1: Cfg.Colors.accent.toString().replace("#", "")
    property string destaque2: Cfg.Colors.critical.toString().replace("#", "")
    property string texto: Cfg.Colors.text.toString().replace("#", "")
    property string wallpaperPath: ""

    readonly property bool canSave: themeName.trim().length > 0 && wallpaperPath.trim().length > 0

    Process {
        id: wallpaperListProc
        command: ["bash", "-c", "find ~/Pictures ~/Imagens ~/Wallpapers ~/wallpapers ~/.wallpapers -maxdepth 2 \\( -iname '*.jpg' -o -iname '*.jpeg' -o -iname '*.png' -o -iname '*.webp' \\) 2>/dev/null | head -60"]
        running: true
        stdout: StdioCollector {
            onStreamFinished: root.wallpaperCandidates = this.text.split("\n").filter((l) => l.length > 0)
        }
    }
    property var wallpaperCandidates: []

    Process {
        id: applyProc
        onExited: (code) => { root.applyResult = code === 0 ? "Tema aplicado!" : "Falha ao aplicar (código " + code + ")" }
    }
    property string applyResult: ""

    function save() {
        applyProc.command = ["bash", Cfg.Config.themeApplyScript,
            root.themeName, root.fundo, root.superficie, root.base,
            root.destaque1, root.destaque2, root.texto, root.wallpaperPath]
        applyProc.running = true
    }

    component ColorSwatchField: RowLayout {
        property string label: ""
        property alias value: input.text
        Layout.fillWidth: true
        spacing: 8
        Text { text: label; color: Cfg.Colors.subtext; font.pixelSize: 12; Layout.preferredWidth: 90 }
        Rectangle {
            width: 22; height: 22; radius: 5
            color: "#" + (input.text.length === 6 ? input.text : "808080")
            border.color: Cfg.Colors.border; border.width: 1
        }
        Rectangle {
            Layout.fillWidth: true; height: 28; radius: Cfg.Config.chipRadius
            color: Cfg.Colors.bgAlt; border.color: input.activeFocus ? Cfg.Colors.accent : Cfg.Colors.border; border.width: 1
            TextInput {
                id: input
                anchors.fill: parent
                anchors.margins: 8
                verticalAlignment: TextInput.AlignVCenter
                color: Cfg.Colors.text
                font.pixelSize: 11
                font.family: Cfg.Config.monoFontFamily
                maximumLength: 6
                selectByMouse: true
                validator: RegularExpressionValidator { regularExpression: /[0-9a-fA-F]{0,6}/ }
            }
        }
    }

    ColumnLayout {
        id: col
        width: parent.width
        spacing: 14

        Text { text: "Criar Tema"; color: Cfg.Colors.subtext; font.bold: true; font.pixelSize: 12 }

        RowLayout {
            Layout.fillWidth: true
            spacing: 8
            Text { text: "Nome"; color: Cfg.Colors.subtext; font.pixelSize: 12; Layout.preferredWidth: 90 }
            Rectangle {
                Layout.fillWidth: true; height: 28; radius: Cfg.Config.chipRadius
                color: Cfg.Colors.bgAlt; border.color: nameInput.activeFocus ? Cfg.Colors.accent : Cfg.Colors.border; border.width: 1
                TextInput {
                    id: nameInput
                    anchors.fill: parent
                    anchors.margins: 8
                    verticalAlignment: TextInput.AlignVCenter
                    color: Cfg.Colors.text
                    font.pixelSize: 12
                    text: root.themeName
                    selectByMouse: true
                    onTextEdited: root.themeName = text
                }
            }
        }

        ColumnLayout {
            Layout.fillWidth: true
            spacing: 8
            Text { text: "Esquema de cores"; color: Cfg.Colors.dim; font.pixelSize: 10 }
            ColorSwatchField { label: "Fundo"; value: root.fundo; onValueChanged: root.fundo = value }
            ColorSwatchField { label: "Superfície"; value: root.superficie; onValueChanged: root.superficie = value }
            ColorSwatchField { label: "Base"; value: root.base; onValueChanged: root.base = value }
            ColorSwatchField { label: "Destaque 1"; value: root.destaque1; onValueChanged: root.destaque1 = value }
            ColorSwatchField { label: "Destaque 2"; value: root.destaque2; onValueChanged: root.destaque2 = value }
            ColorSwatchField { label: "Texto"; value: root.texto; onValueChanged: root.texto = value }
        }

        Rectangle { Layout.fillWidth: true; height: 1; color: Cfg.Colors.divider }

        ColumnLayout {
            Layout.fillWidth: true
            spacing: 6
            Text { text: "Wallpaper"; color: Cfg.Colors.dim; font.pixelSize: 10 }

            Rectangle {
                Layout.fillWidth: true; height: 28; radius: Cfg.Config.chipRadius
                color: Cfg.Colors.bgAlt; border.color: wpInput.activeFocus ? Cfg.Colors.accent : Cfg.Colors.border; border.width: 1
                TextInput {
                    id: wpInput
                    anchors.fill: parent
                    anchors.margins: 8
                    verticalAlignment: TextInput.AlignVCenter
                    color: Cfg.Colors.text
                    font.pixelSize: 11
                    text: root.wallpaperPath
                    selectByMouse: true
                    onTextEdited: root.wallpaperPath = text
                }
            }

            Text {
                text: root.wallpaperCandidates.length > 0
                    ? "Ou escolhe da lista (~/Pictures, ~/Imagens, ~/Wallpapers):"
                    : "Nenhuma imagem encontrada nas pastas comuns — cola o caminho acima."
                color: Cfg.Colors.dim
                font.pixelSize: 10
                wrapMode: Text.Wrap
                Layout.fillWidth: true
            }

            Rectangle {
                Layout.fillWidth: true
                Layout.preferredHeight: Math.min(root.wallpaperCandidates.length * 26, 130)
                visible: root.wallpaperCandidates.length > 0
                color: "transparent"
                clip: true

                Flickable {
                    anchors.fill: parent
                    contentHeight: wpList.implicitHeight
                    boundsBehavior: Flickable.StopAtBounds

                    ColumnLayout {
                        id: wpList
                        width: parent.width
                        spacing: 2
                        Repeater {
                            model: root.wallpaperCandidates
                            delegate: Rectangle {
                                required property string modelData
                                Layout.fillWidth: true
                                height: 24
                                radius: 4
                                color: root.wallpaperPath === modelData ? Cfg.Colors.accentDim : (wpHover.containsMouse ? Cfg.Colors.hoverOverlay : "transparent")
                                Text {
                                    anchors.fill: parent
                                    anchors.leftMargin: 6
                                    verticalAlignment: Text.AlignVCenter
                                    text: modelData
                                    color: Cfg.Colors.text
                                    font.pixelSize: 10
                                    elide: Text.ElideMiddle
                                }
                                MouseArea { id: wpHover; anchors.fill: parent; hoverEnabled: true; onClicked: root.wallpaperPath = parent.modelData }
                            }
                        }
                    }
                }
            }
        }

        Rectangle { Layout.fillWidth: true; height: 1; color: Cfg.Colors.divider }

        Rectangle {
            Layout.fillWidth: true; height: 34; radius: Cfg.Config.chipRadius
            color: root.canSave ? Cfg.Colors.accent : Cfg.Colors.bgAlt
            Text {
                anchors.centerIn: parent
                text: "Criar e aplicar tema"
                color: root.canSave ? Cfg.Colors.bg : Cfg.Colors.dim
                font.pixelSize: 12; font.bold: true
            }
            MouseArea { anchors.fill: parent; enabled: root.canSave; onClicked: root.save() }
        }

        Text {
            visible: root.applyResult.length > 0
            text: root.applyResult
            color: root.applyResult.startsWith("Tema aplicado") ? Cfg.Colors.good : Cfg.Colors.critical
            font.pixelSize: 11
            Layout.alignment: Qt.AlignHCenter
        }
    }
}
